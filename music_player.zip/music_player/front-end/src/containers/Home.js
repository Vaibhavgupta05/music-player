import { Login } from "../components/Login"
import React from 'react';
import { Register } from "../components/Register";
import { Singers } from "../components/Singers";
export const Home = ()=>{
    return (
        <>
            
            {/* <Singers/> */}
            <Login/>
            <hr/>
             
        </>
    );
}