   
import React from 'react';    
import {NavLink, Route, Switch} from 'react-router-dom';
import { Singers } from './Singers';
import { Song } from './Song';
import './Dashboard.css';
export const AdminDashBoard = ({msg})=>{
    return (<div className="body">
         <header>
          <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
              <a class="navbar-brand" href="#">JioSaavn</a>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                
                <form class="search">
                    <div class="input-group">
                      <input type="text" class="form-control" placeholder="&#xF002;  Search" aria-label="Username" aria-describedby="basic-addon1" size="70"/>
                    </div>
                  </form>
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                      <div class="nav-link" href="#">
                        <div className="user-name">
                            <h2>{msg}</h2>
                        </div>
                      </div>
                    </li>
                </ul>
              </div>
            </div>
          </nav>
    </header>

    <div class="content">
        <div class="sidebar">
            <h6>LIBRARY</h6>
            <NavLink className="nav-link active" aria-current="page" to="/">
              <span data-feather="home"></span>
              Home
            </NavLink>
            <NavLink className="nav-link active" aria-current="page" to="/singers">
              <span data-feather="home"></span>
              Singers
            </NavLink>
            <NavLink className="nav-link active" aria-current="page" to="/Albums">
              <span data-feather="home"></span>
              Albums
            </NavLink>
            <NavLink className="nav-link active" aria-current="page" to="/Podcasts">
              <span data-feather="home"></span>
              Podcasts
            </NavLink>
            <NavLink className="nav-link active" aria-current="page" to="/Artists">
              <span data-feather="home"></span>
              Artists
            </NavLink>
            <NavLink className="nav-link active" aria-current="page" to="/add">
              <span data-feather="home"></span>
              Add songs
            </NavLink>
            <NavLink className="nav-link active" aria-current="page" to="/delete">
              <span data-feather="home"></span>
              Delete songs
            </NavLink>
        </div>
        <div class="main">
            <div class="section-1">
                <h2>Trending Now</h2> 
                <div class="row">
                     <div class="col-md-2">
                        <div class="box">
                            <div class="img">
                                <a href="#">
                                    <img src="https://c.saavncdn.com/editorial/PunjabseBollywood_20210426183621_150x150.jpg?bch=1619489213" class="w-100" alt="img"/>
                                </a>
                            </div>
                            <div class="desc">
                                <a href="#">
                                    <span class="song-name">Punjab se Bollywood</span>
                                    <p>
                                        213.6K Fans
                                    </p>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="box">
                            <div class="img">
                                <a href="#">
                                    <img src="https://c.saavncdn.com/editorial/2InTuneLataandKishore_20210802153346_150x150.jpg?bch=1627945493" class="w-100" alt="img"/>
                                </a>
                            </div>
                            <div class="desc">
                                <a href="#">
                                    <span class="song-name">2 In Tune</span>
                                    <p>
                                        11K Fans
                                    </p>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="box">
                            <div class="img">
                                <a href="#">
                                    <img src="https://c.saavncdn.com/347/Baarish-Ban-Jaana-Hindi-2021-20210601053345-150x150.jpg?bch=452270" class="w-100" alt="img"/>
                                </a>
                            </div>
                            <div class="desc">
                                <a href="#">
                                    <span class="song-name">Baarish Ban Jaana</span>
                                    <p>
                                        Payal Dev, Stebin Ben
                                    </p>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="box">
                            <div class="img">
                                <a href="#">
                                    <img src="https://c.saavncdn.com/editorial/LoveHurts_20210709041256_150x150.jpg?bch=1628077864" class="w-100" alt="img"/>
                                </a>
                            </div>
                            <div class="desc">
                                <a href="#">
                                    <span class="song-name">Love Hurts</span>
                                    <p>
                                        21.3K Fans
                                    </p>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="box">
                            <div class="img">
                                <a href="#">
                                    <img src="https://c.saavncdn.com/editorial/EssentialSoftRock_20210716040305_150x150.jpg?bch=1627474175" class="w-100" alt="img"/>
                                </a>
                            </div>
                            <div class="desc">
                                <a href="#">
                                    <span class="song-name">Essential Soft Rock</span>
                                    <p>
                                        3.8K Fans
                                    </p>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="box">
                            <div class="img">
                                <a href="#">
                                    <img src="https://c.saavncdn.com/editorial/BollywoodCovers_20210727172833_150x150.jpg?bch=1627584499" class="w-100" alt="img"/>
                                </a>
                            </div>
                            <div class="desc">
                                <a href="#">
                                    <span class="song-name">Bollywood Covers</span>
                                    <p>
                                        27.6K Fans
                                    </p>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                </div>
                
            </div>
            </div>
</div>
<Switch>
        
        <Route path="/singers" exact component={Singers}/>
        
</Switch>
</div>
    );
}
