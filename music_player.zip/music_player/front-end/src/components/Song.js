import React, { useEffect, useState } from 'react';
import './Dashboard.css';
export const Song = (props)=>{
    const [songs, setSongs] = useState([]);
    const [currOrder, setOrder] =useState('asc');
    const audioStyle = {
        width:'400px'
    }
    const imageStyle = {
        height:'100px',
        width:'100px'
    }
    const changeOrder=()=>{

        const button = document.querySelector('#orderbutton');
        if(currOrder==='asc'){
            setOrder('desc')
            button.innerHTML = 'Descending';
        }
        else {
            setOrder('asc');
            button.innerHTML = 'Ascending';
        }    
    }
    let singerName  = props.singerName;
    if(!singerName){
        singerName = props.match.params.singerName;
    }
    useEffect(()=>{
            let url = `${process.env.REACT_APP_SONG_URL}?name=${singerName}`;
            const promise = fetch(url);
            promise.then(response=>{
                response.json().then(data=>{
                    if(currOrder === 'desc')
                    {data.sort((a, b)=>{
                        if(b.name < a.name)
                         return -1;
                        if(b.name > a.name)
                         return 1;
                        return 0; 
                    })}
                    else
                    {data.sort((a, b)=>{
                        if(a.name < b.name)
                         return -1;
                        if(a.name > b.name)
                         return 1;
                        return 0; 
                    })
                    }
                    setSongs(data);
                }).catch(err=>{
                    console.log('JSON Error is ', err);
                })
            }).catch(err=>console.log("Error is ",err));
    });
    return (<>
    <h3 className="song">Songs of {singerName}</h3>
    <br />
    <button className="btn btn-primary" id="orderbutton" onClick={changeOrder}>Sort</button>
    <br />
    <br />
    {songs.map(song=>{
        return (<div>
            <img src={song.imageurl} className="song-image" style={imageStyle}/>
            <p className="song-name">{song.name}</p>
            <audio className="song-control" controls controlsList="nodownload" style={audioStyle}>
                <source src={song.url} type="audio/mp4"></source>
            </audio>
        </div>)
    })}
    </>
    )
}